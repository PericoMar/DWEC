He hecho lo que he podido interpretar que hace el boton de comprar.
Pero no queda claro que es lo que se pide.
Si crear un parrafo hijo o meter un option que sea el mensaje 
(Que no se puede porque no se le puede cambiar el color de fondo al select).
